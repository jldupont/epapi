/**
 * @file epapi_pkt.h
 *
 * @date   2009-06-06
 * @author Jean-Lou Dupont
 */

#ifndef PKT_H_
#define PKT_H_

//dev support
#ifndef EPAPI_H_
	#include "epapi.h"
#endif


	/**
	 * Packet class
	 *
	 */
	class Pkt: public epapiBase {


	private:
		static const int DSZ = 128;

	protected:

		//RX packet type
		int sz;
		char *buf;
		int len;

		//TX packet type
		ei_x_buff *tbuf;

	public:

		/**
		 * Creates a RX packet
		 */
		Pkt();

		/**
		 * Destroys either RX or TX
		 * packet types
		 */
		~Pkt();

		/**
		 * Gets the pointer to
		 * the internal buffer
		 */
		unsigned char *getBuf(void);

		/**
		 * Gets the pointer to the internal
		 * buffer and reallocs, if necessary,
		 * to 'size'
		 *
		 * @param size size of required buffer
		 * @return buffer
		 */
		unsigned char *getBuf(int size);

		/**
		 * Returns the Erlang specific
		 * TX buffer
		 *
		 * @return ei_x_buff buffer
		 */
		ei_x_buff *getTxBuf(void);


		/**
		 * Sets the packet length
		 * ie. not the buffer length
		 *
		 * This method really only
		 * applies to RX packet type and usually
		 * manipulated by the PktHandler.
		 *
		 * @param len packet length
		 */
		void setLength(int len);

		/**
		 * Returns the length
		 * of the packet
		 *
		 * This method really only
		 * applies to RX packet type
		 *
		 * @return packet length
		 */
		int getLength(void);
	};

	/**
	 * Packet Handler
	 *
	 * This class enables customization of the packet handling layer
	 * by providing the capability to configure the input file
	 * descriptor and output file descriptor.  The defaults are
	 * "stdin" and "stdout".
	 */
	class PktHandler: public epapiBase {

	protected:
		int ifd;
		int ofd;


	public:
		/**
		 * Constructor
		 *
		 * Standard input and output descriptors
		 * ie. stdin and stdout
		 */
		PktHandler();

		/**
		 * Constructor
		 *
		 * @param ifd input file descriptor
		 * @param ofd output file descriptor
		 */
		PktHandler(int ifd, int ofd);

		~PktHandler();

		/**
		 * Receive packet
		 *
		 * @param p pointer to packet pointer
		 *
		 * @return 0 SUCCESS
		 * @return 1 FAILURE
		 */
		int rx(Pkt **p);

		/**
		 * Transmit packet
		 *
		 * @param p pointer to packet
		 *
		 * @return 0 SUCCESS
		 * @return 1 FAILURE
		 */
		int tx(Pkt *p);

	protected:
		/**
		 * Receive (blocking) a packet
		 *
		 * @param p packet pointer
		 * @param len packet length
		 *
		 * @return >0  LEN read
		 * @return <=0 ERROR, check errno
		 */
		int rx_exact(Pkt **p, int len);

		/**
		 * Transmits (blocking) a packet
		 *
		 * @param buf packet buffer
		 * @param len packet length
		 *
		 * @return >0   LEN written
		 * @return <=0  ERROR, check errno
		 */
		int tx_exact(char *buf, int len);
	};


#endif /* PKT_H_ */
